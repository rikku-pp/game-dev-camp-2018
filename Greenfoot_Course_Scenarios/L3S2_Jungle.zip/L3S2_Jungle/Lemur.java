import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Lemur here.
 * 
 * @author Oracle Academy
 * @version 3.0
 */
public class Lemur extends Actor
{
    private GreenfootImage Image1;
    private GreenfootImage Image2;
    private GreenfootImage Image3;
    private GreenfootImage Image4;
    private int countBananasEaten;
    private int countHippoCollisions;
    private int countElephantCollisions;
    /**
     * This constructor creates the Lemur and assigns 4 images to it. The first image the lemur 
     * should display is image1. 
     */
    public Lemur()
    {
        Image1 = new GreenfootImage("lemur_up.png");
        Image2 = new GreenfootImage("lemur_down.png");
        Image3 = new GreenfootImage("lemur_left.png");
        Image4 = new GreenfootImage("lemur_right.png");
        setImage(Image1);
    }
    /**
     * Act - do whatever the Lemur wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
       move(1); //Move forward repeatedly
       keyboardControls();
       bananasEaten();
       hippoCrash();
       elephantCrash();
       scoreKeeper();
    }
    /**
     * This method controls the lemur using the arrow keys on the keyboard.
     */
    public void keyboardControls()
    {
        if (Greenfoot.isKeyDown("left")) 
        {
            move(2);
            this.setLocation(this.getX()-5, this.getY());
        }    
        if (Greenfoot.isKeyDown("right"))
        {
            move(2);
            this.setLocation(this.getX()+5, this.getY());
        }
        if (Greenfoot.isKeyDown("up"))
        {
            move(2);
            this.setLocation(this.getX(), this.getY()-5);
        }
        if (Greenfoot.isKeyDown("down"))
        {
            move(2);
            this.setLocation(this.getX(), this.getY()+5);
        }
    }
    /**
     * This method detects if the Lemur collides with ("eats") a banana object. 
     * If the lemur collides with a banana object, the banana should be removed from the scenario. 
     */
    public void bananasEaten()
    {
        Actor getBananas = getOneIntersectingObject(Bananas.class);
        if (getBananas != null)
        {
            getWorld().removeObject(getBananas);
            countBananasEaten++;
        }
    }

    /**
     * This method detects if the Lemur collides with an Elephant object. 
     */
    public void elephantCrash()
    {
        Actor getElephant = getOneIntersectingObject(Elephant.class);
        if (getElephant != null)
        {
            Greenfoot.delay(2);
            this.setLocation(100, 100);
            countElephantCollisions++;
        }
    }

    /**
     * This method detects if the Bee collides with a Hippo object. 
     */
    public void hippoCrash()
    {
        Actor getHippo = getOneIntersectingObject(Hippo.class);
        if (getHippo != null)
        {
            Greenfoot.delay(2);
            this.setLocation(100, 100);
            countElephantCollisions++;
        }
    }

    /**
     * This method keeps the score of the game. If the lemur collects 10 bananas, the player wins. 
     * If the bee collides with the hippo or elephant, the player loses. 
     */
    public void scoreKeeper()
    {
        if (countBananasEaten == 10)
        {
            Greenfoot.stop();
        }
        if (countElephantCollisions == 1)
        {
            Greenfoot.stop();
        }
        if (countHippoCollisions == 1)
        {
            Greenfoot.stop();
        
    }
}
}
