import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class JungleWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class JungleWorld extends World
{

    /**
     * Constructor for objects of class JungleWorld.
     * 
     */
    public JungleWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 

        prepare();
    }

    /**
     * Prepare the world for the start of the program. That is: create the initial
     * objects and add them to the world.
     */
    private void prepare()
    {
        Tree tree = new Tree();
        addObject(tree, 60, 61);
        Tree tree2 = new Tree();
        addObject(tree2, 183, 208);
        Tree tree3 = new Tree();
        addObject(tree3, 300, 342);
        Tree tree4 = new Tree();
        addObject(tree4, 340, 99);
        Tree tree5 = new Tree();
        addObject(tree5, 481, 232);
        Tree tree6 = new Tree();
        addObject(tree6, 518, 89);
        Tree tree7 = new Tree();
        addObject(tree7, 72, 316);
        Bananas bananas = new Bananas();
        addObject(bananas, 88, 65);
        Bananas bananas2 = new Bananas();
        addObject(bananas2, 362, 102);
        Bananas bananas3 = new Bananas();
        addObject(bananas3, 555, 84);
        Bananas bananas4 = new Bananas();
        addObject(bananas4, 519, 222);
        Bananas bananas5 = new Bananas();
        addObject(bananas5, 221, 199);
        Bananas bananas6 = new Bananas();
        addObject(bananas6, 91, 316);
        Bananas bananas7 = new Bananas();
        addObject(bananas7, 338, 340);
        Rock rock = new Rock();
        addObject(rock, 208, 74);
        Rock rock2 = new Rock();
        addObject(rock2, 353, 217);
        Lemur lemur = new Lemur();
        addObject(lemur, 46, 362);
        Elephant elephant = new Elephant();
        addObject(elephant, 266, 268);
        Hippo hippo = new Hippo();
        addObject(hippo, 457, 50);
        Instructions instructions = new Instructions();
        addObject(instructions, 397, 359);
        lemur.setLocation(60, 143);
        bananas6.setLocation(54, 243);
        tree7.setLocation(35, 240);
        instructions.setLocation(302, 376);
        bananas7.setLocation(382, 293);
        tree3.setLocation(348, 295);
        tree5.setLocation(564, 214);
        bananas4.setLocation(539, 229);
        bananas7.setLocation(444, 277);
        tree3.setLocation(423, 262);
        bananas2.setLocation(352, 114);
        bananas3.setLocation(531, 96);
        bananas.setLocation(107, 45);
        tree.setLocation(96, 37);
        bananas6.setLocation(45, 249);
        lemur.setRotation(90);
        lemur.setRotation(45);
        lemur.setLocation(100, 100);
        bananas.setLocation(45, 74);
        tree.setLocation(37, 52);
        bananas6.setLocation(62, 287);
        tree7.setLocation(55, 269);
        bananas5.setLocation(194, 217);
        bananas7.setLocation(424, 277);
        bananas4.setLocation(569, 232);
        bananas3.setLocation(518, 110);
        bananas2.setLocation(338, 119);
        lemur.setLocation(51, 136);
    }
}
