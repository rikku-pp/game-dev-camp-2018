import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Frog here.
 * 
 * @author Oracle Academy 
 * @version L8S6
 */
public class Frog extends Actor
{
    private GreenfootImage image1;
    private GreenfootImage image2;
    private GreenfootImage image3;
    private GreenfootImage image4;

    /**
     * This constructor creates a Frog and assigns four images to it. The first image that the frog displays is image2. 
     */
    public Frog()
    {
        image1 = new GreenfootImage("frog_left.png");
        image2 = new GreenfootImage("frog_right.png");
        image3 = new GreenfootImage("frog_up.png");
        image4 = new GreenfootImage("frog_down.png");
        setImage(image2);
    }

    /**
     * Act - do whatever the Frog wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if (Greenfoot.isKeyDown("left")) 
        {
            move(2);
            this.setImage(image1);
            this.setLocation(this.getX()-5, this.getY());
        }    
        if (Greenfoot.isKeyDown("right"))
        {
            move(2);
            this.setImage(image2);
            this.setLocation(this.getX()+5, this.getY());
        }
        if (Greenfoot.isKeyDown("up"))
        {
            move(2);
            this.setImage(image3);
            this.setLocation(this.getX(), this.getY()-5);
        }
        if (Greenfoot.isKeyDown("down"))
        {
            move(2);
            this.setImage(image4);
            this.setLocation(this.getX(), this.getY()+5);
        }
        frogSound();
    }
    /**
     * Play a sound if the "s" key is pressed on the keyboard.
     */
    public void frogSound()
    {
        if(Greenfoot.isKeyDown("s"))
        {
            Greenfoot.playSound("frog.wav");
        }
    }
}
