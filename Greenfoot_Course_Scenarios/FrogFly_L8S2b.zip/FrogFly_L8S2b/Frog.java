import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Frog here.
 * 
 * @author Oracle Academy 
 * @version L7S3
 */
public class Frog extends Actor
{
    /**
     * Act - do whatever the Frog wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if (Greenfoot.isKeyDown("left")) 
        {
            move(2);
            this.setImage("frog_left.png");
            this.setLocation(this.getX()-5, this.getY());
        }    
        if (Greenfoot.isKeyDown("right"))
        {
            move(2);
            this.setImage("frog_right.png");
            this.setLocation(this.getX()+5, this.getY());
        }
        if (Greenfoot.isKeyDown("up"))
        {
            move(2);
            this.setImage("frog_up.png");
            this.setLocation(this.getX(), this.getY()-5);
        }
        if (Greenfoot.isKeyDown("down"))
        {
            move(2);
            this.setImage("frog_down.png");
            this.setLocation(this.getX(), this.getY()+5);
        }
    }
}
