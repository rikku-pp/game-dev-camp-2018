import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class FrogWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FrogWorld extends World
{

    /**
     * Constructor for objects of class FrogWorld.
     * 
     */
    public FrogWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(700, 500, 1); 

        prepare();
    }

    /**
     * Prepare the world for the start of the program. That is: create the initial
     * objects and add them to the world.
     */
    private void prepare()
    {
        Instructions instructions = new Instructions();
        addObject(instructions, 309, 381);
        instructions.setLocation(301, 374);
        Frog frog = new Frog();
        addObject(frog, 48, 46);
        frog.setLocation(50, 50);
        Rock rock = new Rock();
        addObject(rock, 164, 118);
        Rock rock2 = new Rock();
        addObject(rock2, 419, 260);
        Ant ant = new Ant();
        addObject(ant, 512, 78);
        Ant ant2 = new Ant();
        addObject(ant2, 412, 167);
        Fly fly = new Fly();
        addObject(fly, 244, 57);
        Fly fly2 = new Fly();
        addObject(fly2, 58, 157);
        Fly fly3 = new Fly();
        addObject(fly3, 201, 238);
        Fly fly4 = new Fly();
        addObject(fly4, 61, 264);
        Fly fly5 = new Fly();
        addObject(fly5, 338, 301);
        Fly fly6 = new Fly();
        addObject(fly6, 326, 182);
        Fly fly7 = new Fly();
        addObject(fly7, 410, 58);
        Fly fly8 = new Fly();
        addObject(fly8, 549, 165);
        Fly fly9 = new Fly();
        addObject(fly9, 556, 294);
        Fly fly10 = new Fly();
        addObject(fly10, 469, 201);
        fly2.setRotation(200);
        fly3.setRotation(150);
        fly.setRotation(20);
        fly7.setRotation(290);
        fly10.setRotation(140);
        fly8.setRotation(10);
    }
}
