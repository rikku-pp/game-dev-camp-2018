import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Ant here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Ant extends Actor
{
    /**
     * Act - do whatever the Ant wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if(Greenfoot.getRandomNumber(100)<10)
        {
            move(5);
            turn(Greenfoot.getRandomNumber(20));
        }  
        else
        {
            move(5);
            turn(Greenfoot.getRandomNumber(10));
        } 
        atWorldEdge();
    }

    /**
     * This method checks if the object is at the edge of the world. If true, the object turns
     * 180 degrees.
     */
    public void atWorldEdge()
    {
        if(getX() <= 10 || getX() >= getWorld().getWidth() - 10)
        {
            turn(180);
        }
        if(getY() <= 10 || getY() >= getWorld().getHeight() - 10)
        {
            turn(180);
        }
    }
}
