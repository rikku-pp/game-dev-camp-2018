import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Frog here.
 * 
 * @author Oracle Academy 
 * @version L8S6
 */
public class Frog extends Actor
{
    private GreenfootImage image1;
    private GreenfootImage image2;
    private GreenfootImage image3;
    private GreenfootImage image4;
    private int countFliesEaten;
    private int countAntCollisions;
    private int countRockCollisions;
    /**
     * This constructor creates a Frog and assigns four images to it. The first image that the frog displays is image2. 
     */
    public Frog()
    {
        image1 = new GreenfootImage("frog_left.png");
        image2 = new GreenfootImage("frog_right.png");
        image3 = new GreenfootImage("frog_up.png");
        image4 = new GreenfootImage("frog_down.png");
        setImage(image2);
    }

    /**
     * Act - do whatever the Frog wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        keyControls();
        frogSound();
        eatFlies();
        antCollisions();
        rockCollisions();
        scoreKeeper();
    }
    /**
     * Manage the movement of the frog with the arrow keys on the keyboard.
     */
    public void keyControls()
    {
        if (Greenfoot.isKeyDown("left")) 
        {
            move(2);
            this.setImage(image1);
            this.setLocation(this.getX()-5, this.getY());
        }    
        if (Greenfoot.isKeyDown("right"))
        {
            move(2);
            this.setImage(image2);
            this.setLocation(this.getX()+5, this.getY());
        }
        if (Greenfoot.isKeyDown("up"))
        {
            move(2);
            this.setImage(image3);
            this.setLocation(this.getX(), this.getY()-5);
        }
        if (Greenfoot.isKeyDown("down"))
        {
            move(2);
            this.setImage(image4);
            this.setLocation(this.getX(), this.getY()+5);
        }
    }  
    /**
     * Play a sound if the "s" key is pressed on the keyboard.
     */
    public void frogSound()
    {
        if(Greenfoot.isKeyDown("s"))
        {
            int i = 0;
            while(i < 3)
            { 
                Greenfoot.playSound("frog.wav");
                i++;
            }
        }
    }

    /**
     * This method detects if the Frog is colliding with a fly object. If true, remove the fly object from the world.
     */
    public void eatFlies()
    {
        Actor getFly = getOneIntersectingObject(Fly.class);
        if(getFly != null)
        {
            getWorld().removeObject(getFly);
            countFliesEaten++;    
        }
    }
    /**
     * This method detects if the Frog collides with an Ant object. 
     */
    public void antCollisions()
    {
        Actor getAnt = getOneIntersectingObject(Ant.class);
        if (getAnt != null)
        {
            Greenfoot.delay(2);
            this.setLocation(100, 100);
            countAntCollisions++;
        }
    }
    /**
     * This method detects if the Frog collides with a Rock object. 
     */
    public void rockCollisions()
    {
        Actor getRock = getOneIntersectingObject(Rock.class);
        if (getRock != null)
        {
            Greenfoot.delay(2);
            this.setLocation(100, 100);
            countRockCollisions++;
        }
    }
    /**
     * This method keeps the score of the game. If the Frog eats 10 flies, the player wins. 
     * If the frog collides with the ant 5 times or the rock 5 times, the player loses. 
     */
    public void scoreKeeper()
    {
        if (countFliesEaten == 10)
        {
            setImage("YouWin.png");
            Greenfoot.stop();
        }
        if (countAntCollisions == 5)
        {
            setImage("GameOver.png");
            int i = 0;
            while (i < 10){
                getWorld().addObject(new Ant(), Greenfoot.getRandomNumber(getWorld().getWidth()), 
                    Greenfoot.getRandomNumber(getWorld().getHeight()));
                i++;
            }
            Greenfoot.stop();
        }
        if (countRockCollisions == 5)
        {
            setImage("GameOver.png");
            int i = 0;
            while (i < 10){
                getWorld().addObject(new Rock(), Greenfoot.getRandomNumber(getWorld().getWidth()), 
                    Greenfoot.getRandomNumber(getWorld().getHeight()));
                i++;
            }
            Greenfoot.stop();
        }
    }
}
